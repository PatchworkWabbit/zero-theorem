"""Pydroid3: open this runner after extracting zero_theorem_task4_tests.zip."""
import argparse
import contextlib
import copy
import csv
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import random
import tempfile
import time

ENGINE = 'zero_theoremV4.7.11.py'
PHONE_CASES = ['single_path_manifest', 'erase_0_evidence', 'duplicate_id_conflict']


def bundle_folder():
    candidates = []
    if '__file__' in globals(): candidates.append(Path(__file__).resolve().parent)
    candidates.append(Path.cwd())
    for downloads in (Path('/storage/emulated/0/Download'), Path('/storage/emulated/0/Downloads')):
        if downloads.exists():
            candidates.extend(sorted(downloads.glob('zero_theorem_task4*'), key=lambda p:p.stat().st_mtime, reverse=True))
            candidates.extend(sorted(downloads.glob('Zero_Theorem_Task4*'), key=lambda p:p.stat().st_mtime, reverse=True))
    for folder in candidates:
        if (folder / ENGINE).is_file() and (folder / 'task4_fixture/baseline.json').is_file(): return folder
    entered = input('Paste the extracted Task 4 folder path: ').strip().strip('"')
    folder = Path(entered)
    if not (folder / ENGINE).is_file(): raise FileNotFoundError('Engine missing in that folder: ' + str(folder / ENGINE))
    return folder


def digest(raw): return hashlib.sha256(raw).hexdigest()
def encoded(value): return json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')
def save(path, value): path.write_bytes(encoded(value))


def load_engine(folder):
    spec = importlib.util.spec_from_file_location('task4_engine', folder / ENGINE)
    engine = importlib.util.module_from_spec(spec); spec.loader.exec_module(engine)
    return engine


def record_arrays(m, e): return {d:e._zr_records(m,d) for d in e._ZR_DOMAINS}


def packed_number(tree, n, e):
    if isinstance(tree, dict):
        if set(tree) == {'q'}:
            q=tree['q']; return e.Fraction(int(q[0]),int(q[1])) == n
        return any(packed_number(child,n,e) for child in tree.values())
    if isinstance(tree,list): return any(packed_number(child,n,e) for child in tree)
    return False


def mentions_number(domain, rec, n, e):
    if domain == 'rational':
        return e.number(rec['value']) == n or any(e.number(v)==n for v in e.rational_tree_leaves(rec['tree']))
    if domain == 'complex': return e.number(rec['real']) == n or e.number(rec['imaginary']) == n
    if domain == 'symbolic': return packed_number(rec.get('construction'),n,e) or e.symbolic_unpack(rec['exact']) == n
    if domain == 'calculus': return any(e.number(c)==n for c in rec['coefficients'])
    if domain == 'roles':
        body=rec.get('body',{})
        return body.get('kind')=='numeric' and e.number(body['value'])==n
    return False


def damaged_case(name, baseline, e):
    m=copy.deepcopy(baseline); changes=[]; removed={d:set() for d in e._ZR_DOMAINS}
    records=record_arrays(m,e)
    if name == 'control': pass
    elif name in ('single_path_manifest','single_path_legacy','dependent_paths'):
        ids={20}
        if name == 'dependent_paths':
            for rec in records['rational']:
                if rec['pathway'] in e._ZR_ARITHMETIC:
                    parent=next((p for p in rec['parents'] if records['rational'][p]['pathway'] in e._ZR_ARITHMETIC),None)
                    if parent is not None: ids={parent,rec['id']};break
            if len(ids)!=2: raise AssertionError('No dependent binary pair in fixture')
        removed['rational']=ids
        if name == 'single_path_legacy':
            m['zero_recovery']['manifest_initialized']=False
            m['zero_recovery']['manifest']={}
            changes.append({'action':'remove_manifest_evidence','path':'zero_recovery.manifest',
                            'creation_events_and_construction_keys_retained':True})
    elif name == 'value_conflict':
        rec=records['rational'][20]; changes.append({'action':'replace','path':'expressions[id=20].value','before':rec['value'],'after':'123456'})
        rec['value']='123456'
    elif name == 'parent_conflict':
        rec=records['rational'][20];changes.append({'action':'replace','path':'expressions[id=20].parents','before':rec['parents'],'after':[0,2]})
        rec['parents']=[0,2]
    elif name == 'duplicate_id_conflict':
        duplicate=copy.deepcopy(records['rational'][20]);duplicate['value']='123456'
        m['expressions'].append(duplicate)
        changes.append({'action':'append_conflicting_record','path':'expressions','duplicate_id':20,'new_payload':duplicate})
    elif name == 'manifest_recipe_conflict':
        recipe=m['zero_recovery']['manifest']['rational']['20']['recipe']
        old=recipe['tree']['op'];recipe['tree']['op']='+' if old!='+' else '*'
        changes.append({'action':'replace','path':'zero_recovery.manifest.rational.20.recipe.tree.op','before':old,'after':recipe['tree']['op'],'expression_record_intact':True})
    elif name.startswith('erase_'):
        _, number, mode=name.split('_');n=int(number)
        for domain,items in records.items():
            removed[domain]={rec['id'] for rec in items if mentions_number(domain,rec,n,e)}
        # Erase typed descendants too; preserve ID labels, counters and the rule code.
        while True:
            additions=0
            for domain,items in records.items():
                for rec in items:
                    if rec['id'] in removed[domain]:continue
                    refs=[(domain,p) for p in rec.get('parents',[])]+[(ref['archive'],ref['id']) for ref in rec.get('sources',[])]
                    nexus=rec.get('nexus',{})
                    if domain=='symbolic': refs.extend(('symbolic',nexus[k]) for k in ('source_id','selected_value_id') if k in nexus)
                    if any(idx in removed.get(kind,set()) for kind,idx in refs):
                        removed[domain].add(rec['id']);additions+=1
            if not additions:break
        changes.append({'action':'erase_numeric_records_and_typed_descendants','number':n,
            'scope':'rational value/leaves, complex components, symbolic numeric constants/results, calculus coefficients, numeric role bodies, and typed descendants',
            'ids_counters_foundation_registry_and_executable_rules_retained':True})
        if mode == 'evidence':
            for domain,ids in removed.items():
                for idx in ids:
                    m['zero_recovery']['manifest'][domain][str(idx)]={'digest':None,'recipe':None,'redacted':True}
            for idx in removed['rational']:m['known_expression_keys'][idx]=None
            before=len(m['genesis']['events'])
            m['genesis']['events']=[ev for ev in m['genesis']['events'] if not(ev.get('type')=='expression_created' and ev.get('expression_id') in removed['rational'])]
            changes.append({'action':'redact_removed_record_manifests_keys_and_creation_events',
                'manifest_entries':sum(map(len,removed.values())),'construction_keys':len(removed['rational']),
                'creation_events_removed':before-len(m['genesis']['events']),
                'scope_note':'Other journals, registries and executable rules survive; this is not erasure of every trace of a number.'})
    elif name == 'random_byte_span_404':
        raw=encoded(m);recraw=encoded(m['expressions'][20]);start=raw.index(recraw)
        cut=start+random.Random(404).randint(1,len(recraw)-40);size=31
        result=raw[:cut]+raw[cut+size:]
        changes.append({'action':'delete_byte_span','offset':cut,'length':size,'random_seed':404,'containing_record_id':20,'deleted_utf8':raw[cut:cut+size].decode('utf-8')})
        return result,changes,removed
    else: raise ValueError('Unknown case: '+name)
    for domain,ids in removed.items():
        if not ids:continue
        kept=[]
        for rec in records[domain]:
            if rec['id'] in ids:
                changes.append({'action':'remove_record','archive':domain,'id':rec['id'],'value':rec.get('value'),'original_payload_sha256':e._zr_digest(e._zr_payload(rec))})
            else:kept.append(rec)
        if domain=='rational':m['expressions']=kept
        else:m[domain+'_archive']['expressions']=kept
    return encoded(m),changes,removed


ALL_CASES=['control','single_path_manifest','single_path_legacy','dependent_paths','value_conflict',
           'parent_conflict','duplicate_id_conflict','manifest_recipe_conflict',
           'erase_4_records','erase_4_evidence','erase_1_records','erase_1_evidence',
           'erase_0_records','erase_0_evidence','random_byte_span_404']


def archive_comparison(baseline, actual, e):
    out={}
    for domain,expected in record_arrays(baseline,e).items():
        observed={rec['id']:e._zr_digest(e._zr_payload(rec)) for rec in e._zr_records(actual,domain)}
        missing=[];changed=[]
        for rec in expected:
            idx=rec['id']
            if idx not in observed:missing.append(idx)
            elif observed[idx]!=e._zr_digest(e._zr_payload(rec)):changed.append(idx)
        out[domain]={'baseline_records':len(expected),'missing_ids':missing,'changed_ids':changed,
                     'extra_records':len(observed)-len(expected)+len(missing)}
    return out


def partial_recovery_count(report, removed, baseline, e):
    branch=report['trials']['recovery']
    proposal=branch.get('memory_path') if branch.get('status')=='ready' else branch.get('preflight_proposal')
    if not proposal or not Path(proposal).is_file(): return 0
    actual=json.loads(Path(proposal).read_text())
    count=0
    for domain,expected in record_arrays(baseline,e).items():
        by_id={r.get('id'):r for r in e._zr_records(actual,domain) if isinstance(r,dict)}
        for rec in expected:
            idx=rec['id']
            if idx in removed[domain] and idx in by_id and e._zr_payload(by_id[idx])==e._zr_payload(rec):count+=1
    return count


def run_case(name, baseline, baseline_path, work, e):
    case=work/name;case.mkdir()
    raw,changes,removed=damaged_case(name,baseline,e)
    path=case/'damaged.json';path.write_bytes(raw)
    save(case/'change_log.json',{'case':name,'baseline_sha256':digest(baseline_path.read_bytes()),
         'damaged_sha256':digest(raw),'changes':changes,'removed_ids':{d:sorted(ids) for d,ids in removed.items()}})
    started=time.perf_counter();log=io.StringIO()
    with contextlib.redirect_stdout(log):
        report=e.zero_adaptive_recovery(str(path),str(baseline_path),recovery_seconds=1.0)
    (case/'engine_output.txt').write_text(log.getvalue(),encoding='utf-8')
    source_preserved=path.read_bytes()==raw
    if report.get('status')!='selected_and_resumed':raise AssertionError(name+': no validated operational continuation')
    selected=e._zg_check(report['active_memory'])
    audit=e.archive_link_audit(selected)
    observed=e.zero_core(selected,'verification',operation='observe')
    coverage=e.zero_core_report(selected)
    if audit['issues'] or observed['contradictions'] or not coverage['complete']:
        raise AssertionError(name+': selected archive failed post-run validation')
    selected_branch=report['selected_branch']
    comparison=archive_comparison(baseline,selected,e)
    exact_prefix=not any(v['missing_ids'] or v['changed_ids'] for v in comparison.values())
    if selected_branch=='recovery' and not exact_prefix:
        raise AssertionError(name+': recovered archive changed baseline constructions')
    expected_recovery={'control','single_path_manifest','single_path_legacy','dependent_paths','value_conflict','parent_conflict'}
    if name in expected_recovery and selected_branch!='recovery':
        raise AssertionError(name+': supported recovery did not complete')
    if name in ('duplicate_id_conflict','manifest_recipe_conflict') and report['trials']['recovery']['status']=='ready':
        raise AssertionError(name+': conflicting evidence was incorrectly accepted')
    if not source_preserved:raise AssertionError(name+': damaged input changed')
    source_snapshot_preserved=Path(report['source_snapshot']).read_bytes()==raw
    if not source_snapshot_preserved:raise AssertionError(name+': source snapshot changed')
    expected_keys={e._zg_identity(rec) for rec in baseline['expressions']}
    selected_keys={e._zg_identity(rec) for rec in selected['expressions']}
    result={'case':name,'passed':True,'removed_records':{d:len(ids) for d,ids in removed.items()},
        'mutation_count':len(changes),'selected_branch':selected_branch,'new_lineage':report['new_lineage'],
        'recovery_status':report['trials']['recovery']['status'],'regeneration_status':report['trials']['regeneration']['status'],
        'recovery_reason':report['trials']['recovery'].get('reason'),
        'inherited_and_current_recovery_events':report['trials']['recovery'].get('reconstructed_records',0),
        'restored_missing_records_in_recovery_proposal':partial_recovery_count(report,removed,baseline,e),
        'continuation_verified':report['trials'][selected_branch]['continuation_verified'],
        'structural_issues':audit['issues'],'independent_rational_contradictions':len(observed['contradictions']),
        'zero_core_coverage_complete':coverage['complete'],'source_preserved':source_preserved,
        'snapshot_preserved':source_snapshot_preserved,'baseline_archive_prefix_exact':exact_prefix,
        'archive_comparison':comparison,'selected_rational_records':len(selected['expressions']),
        'baseline_rational_constructions_found':len(expected_keys & selected_keys),'baseline_rational_constructions_total':len(expected_keys),
        'historical_identity_claimed_for_regeneration':False,
        'elapsed_seconds':time.perf_counter()-started,
        'recovery_seconds':report['trials']['recovery']['elapsed_seconds'],
        'regeneration_seconds':report['trials']['regeneration']['elapsed_seconds']}
    save(case/'result.json',result)
    return result


def run_matrix(folder, work, names):
    e=load_engine(folder);baseline_path=(folder/'task4_fixture/baseline.json').resolve()
    baseline_raw=baseline_path.read_bytes();baseline=e._zg_check(str(baseline_path))
    assert baseline['foundation']['states']==[0,1,2,3,4,5,6]
    work.mkdir(parents=True,exist_ok=False)
    results=[]
    for name in names:
        print('Running:',name,flush=True)
        result=run_case(name,baseline,baseline_path,work,e)
        if baseline_path.read_bytes()!=baseline_raw:raise AssertionError('Baseline bytes changed')
        result['baseline_preserved']=True;results.append(result)
        save(work/'summary.json',{'schema':1,'engine':ENGINE,'engine_sha256':digest((folder/ENGINE).read_bytes()),
            'baseline_sha256':digest(baseline_raw),'baseline_rational_records':len(baseline['expressions']),
            'baseline_preserved':True,'passed_cases':len(results),'total_cases':len(names),'results':results})
        print('  PASS |',result['selected_branch'],'| recovery:',result['recovery_status'],
              '| archive:',result['selected_rational_records'],'| original inputs preserved',flush=True)
    with (work/'results.csv').open('w',encoding='utf-8',newline='') as f:
        fields=['case','selected_branch','recovery_status','continuation_verified','selected_rational_records',
                'structural_issues','independent_rational_contradictions','source_preserved','baseline_preserved',
                'baseline_archive_prefix_exact','restored_missing_records_in_recovery_proposal','elapsed_seconds']
        writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
        for result in results:writer.writerow({k:result[k] for k in fields})
    print('\nTASK 4:',len(results),'/',len(names),'cases passed.')
    print('Baseline and damaged inputs preserved. Full results:',work)
    return results


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--all',action='store_true')
    parser.add_argument('--cases')
    parser.add_argument('--output')
    args=parser.parse_args()
    folder=bundle_folder()
    names=ALL_CASES if args.all else args.cases.split(',') if args.cases else PHONE_CASES
    if any(name not in ALL_CASES for name in names):raise ValueError('Unknown case')
    if args.output:work=Path(args.output).resolve()
    else:
        # Reserve a unique name; run_matrix creates its evidence folder.
        reserve=Path(tempfile.mkdtemp(prefix='task4_run_',dir=folder));reserve.rmdir();work=reserve
    print('TASK 4 | engine:',ENGINE,'| bundle:',folder,flush=True)
    run_matrix(folder,work,names)

if __name__=='__main__':main()
