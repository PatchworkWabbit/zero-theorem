"""Pydroid3: extract the ZIP to a separate folder, open this file and press Run."""
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile

folder = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('zero_task3', folder / 'zero_theoremV4.7.10.py')
engine = importlib.util.module_from_spec(spec)
spec.loader.exec_module(engine)
fixture = folder / 'task2_source' / 'zero_theorem_rabbitholes_v41_memory.json.zero-body-candidate.json'
raw = fixture.read_bytes()
baseline_memory = json.loads(raw)
work = Path(tempfile.mkdtemp(prefix='task3_demo_', dir=folder))
baseline = work / 'baseline.json'
source = work / 'damaged-copy.json'
baseline.write_bytes(raw)
damaged = json.loads(raw)
damaged['expressions'] = damaged['expressions'][:4]
source.write_text(json.dumps(damaged), encoding='utf-8')
original = source.read_bytes()
print('TASK 3: controlled heavy-loss demonstration')
print('Rational records retained:', len(damaged['expressions']), '/', len(baseline_memory['expressions']))
print('Working folder:', work, flush=True)
report = engine.zero_adaptive_recovery(str(source), str(baseline))
source_preserved = source.read_bytes() == original
baseline_preserved = baseline.read_bytes() == raw
if not source_preserved or not baseline_preserved:
    raise RuntimeError('Input preservation check failed')
if report['status'] != 'selected_and_resumed':
    print('Trials are checkpointed; status:', report['status'])
else:
    checked = engine._zg_check(report['active_memory'])
    branch = report['trials'][report['selected_branch']]
    print('\nDEMO RESULT')
    print('Selected branch:', report['selected_branch'])
    print('Fresh lineage:', report['new_lineage'])
    print('Archive validation: PASS')
    print('Continued exploration and save:', branch['continuation_verified'])
    print('Rational records:', len(checked['expressions']))
    print('Damaged source preserved:', source_preserved)
    print('Baseline preserved:', baseline_preserved)
    print('Recovery evidence and pending paths remain in the working folder.')
summary = {k: report.get(k) for k in ('status', 'selected_branch', 'new_lineage',
    'historical_identity_proven', 'lost_fraction', 'target_records', 'active_memory')}
summary.update(source_preserved=source_preserved, baseline_preserved=baseline_preserved,
    source_sha256=hashlib.sha256(original).hexdigest(), trials=report.get('trials'))
(work / 'demo-result.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
