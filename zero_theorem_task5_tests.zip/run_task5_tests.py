"""Pydroid3: extract the ZIP, open this runner, press Run."""
import argparse
import importlib.util
import io
import json
from pathlib import Path
import sys
import time
import unittest

ENGINE='zero_theoremV4.7.12.py'
PHONE_TESTS=[
 'test_frozen_baseline_all_five_domains_pass_read_only',
 'test_replay_does_not_call_exploration_kernels',
 'test_wrong_complex_constructor_rejected',
 'test_symbolic_matching_value_and_tree_still_requires_parents',
 'test_wrong_calculus_constructor_rejected',
 'test_named_role_must_preserve_payload',
 'test_new_integer_bridge_accepted_and_saved_continuation',
 'test_bridge_operand_can_participate_in_rational_feedback',
 'test_legacy_plain_leaf_bridge_and_descendant_remain_valid',
 'test_normal_save_blocks_bad_record_and_preserves_active_file',
]

def bundle_folder():
    candidates=[]
    if '__file__' in globals():candidates.append(Path(__file__).resolve().parent)
    candidates.append(Path.cwd())
    for downloads in [Path('/storage/emulated/0/Download'),Path('/storage/emulated/0/Downloads')]:
        if downloads.is_dir():
            candidates.extend(sorted(downloads.glob('zero_theorem_task5*'),key=lambda p:p.stat().st_mtime,reverse=True))
            candidates.extend(sorted(downloads.glob('Zero_Theorem_Task5*'),key=lambda p:p.stat().st_mtime,reverse=True))
    for folder in candidates:
        if (folder/ENGINE).is_file() and (folder/'task4_fixture/baseline.json').is_file():return folder
    raise FileNotFoundError('Open run_task5_tests.py inside the extracted zero_theorem_task5_tests folder. Keep the engine and fixture folders beside it.')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--full',action='store_true');args=parser.parse_args()
    folder=bundle_folder();sys.path.insert(0,str(folder))
    spec=importlib.util.spec_from_file_location('task5_checks',folder/'test_zero_theorem_v4712_domains.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    if args.full:
        suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(name) for name in [
          'test_zero_theorem_v4712_domains','test_zero_theorem_v4712_adaptive',
          'test_zero_theorem_v4712_regression','test_recipe_consistency_v4712'])
    else:suite=unittest.TestSuite(module.DomainReplayTests(name) for name in PHONE_TESTS)
    print('TASK 5 | engine:',ENGINE,'| bundle:',folder,flush=True)
    log=io.StringIO();started=time.perf_counter()
    class LiveResult(unittest.TextTestResult):
        def addSuccess(self,test):
            super().addSuccess(test);print('  PASS |',test._testMethodName,flush=True)
        def addFailure(self,test,err):
            super().addFailure(test,err);print('  FAIL |',test._testMethodName,flush=True)
        def addError(self,test,err):
            super().addError(test,err);print('  ERROR |',test._testMethodName,flush=True)
    result=unittest.TextTestRunner(stream=log,verbosity=2,resultclass=LiveResult).run(suite)
    report={'engine':ENGINE,'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
      'passed':result.wasSuccessful(),'seconds':round(time.perf_counter()-started,4),'scope':'disposable fixtures; no user memory opened',
      'details':log.getvalue()}
    output=folder/'task5_phone_results.json';output.write_text(json.dumps(report,indent=2)+'\n')
    if not result.wasSuccessful():print(log.getvalue())
    print('\nTASK 5:',result.testsRun-len(result.failures)-len(result.errors),'/',result.testsRun,'checks passed.')
    print('Test inputs were disposable copies. No user memory opened.')
    print('Full results:',output)
    return 0 if result.wasSuccessful() else 1

if __name__=='__main__':raise SystemExit(main())
