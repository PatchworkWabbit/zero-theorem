"""Publish compact evidence; repair never receives the comparison baseline."""
import copy,hashlib,importlib.util,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('case_engine',ROOT/'zero_theoremV4.7.13.py');e=importlib.util.module_from_spec(spec);spec.loader.exec_module(e)
legacy=json.loads((ROOT/'task4_fixture/baseline.json').read_text());base,ready=e._zr_preflight(legacy,vars(e));assert ready
cases=[]
def probe(name,damaged,expected):
    before=copy.deepcopy(damaged);candidate,ready=e._zr_preflight(damaged,vars(e))
    restored=[event for event in candidate['zero_recovery']['events'] if event['status']=='recovered' and event not in before['zero_recovery']['events']]
    payload_equal=all([e._zr_payload(r) for r in e._zr_records(candidate,d)]==[e._zr_payload(r) for r in e._zr_records(base,d)] for d in e._ZR_DOMAINS)
    cases.append({'name':name,'expected_ready':expected,'ready':ready,'input_unchanged':damaged==before,
      'construction_payloads_equal_baseline':payload_equal,'recovered_slots':[[event['archive'],event['id']] for event in restored],
      'pending_slots':[[d,r['id']] for d in e._ZR_DOMAINS for r in e._zr_records(candidate,d) if r.get('status')=='zero_recovery_pending'],
      'accepted_passage_counts_unchanged':candidate['zero_core']['record_passages']==before['zero_core']['record_passages']})
    assert ready==expected and damaged==before
for d in ['complex','symbolic','calculus','roles']:
    m=copy.deepcopy(base);e._zr_records(m,d).pop();probe('missing_last_'+d,m,True)
m=copy.deepcopy(base)
for d in ['complex','symbolic','calculus','roles']:e._zr_records(m,d).clear()
probe('all_258_nonrational_records_missing_with_recipes',m,True)
m=copy.deepcopy(base);m['roles_archive']['expressions']=[r for r in m['roles_archive']['expressions'] if r['id'] not in (0,7)]
m['calculus_archive']['expressions']=[r for r in m['calculus_archive']['expressions'] if r['id'] not in (0,2)]
probe('role_calculus_dependency_chain',m,True)
m=copy.deepcopy(base);e._zr_records(m,'complex').pop();m['zero_recovery']['manifest']['complex']['125']['typed_recipe']['operation']='?'
probe('contradictory_missing_recipe',m,False)
m=copy.deepcopy(base);e._zr_records(m,'complex').pop();m['zero_recovery']['manifest']['complex']['125'].pop('typed_recipe');m['complex_archive']['known_keys']=[]
probe('no_recipe_or_legacy_key',m,False)
result={'engine':'V4.7.13','engine_sha256':hashlib.sha256((ROOT/'zero_theoremV4.7.13.py').read_bytes()).hexdigest(),
 'fixture_sha256':hashlib.sha256((ROOT/'task4_fixture/baseline.json').read_bytes()).hexdigest(),
 'scope':'deleted record slots; retained mathematical rules, dependencies, recipes/digests and supporting archive structures; no baseline repair file',
 'cases':cases}
(ROOT/'task6_case_results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'cases':len(cases),'as_expected':all(c['ready']==c['expected_ready'] and c['input_unchanged'] for c in cases),'complete_archive_case_recovered':len(cases[4]['recovered_slots'])}))
