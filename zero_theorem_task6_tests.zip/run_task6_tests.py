"""Pydroid3: extract the ZIP, open this runner, press Run."""
import argparse
import importlib.util
import io
import json
from pathlib import Path
import sys
import time
import unittest

ENGINE='zero_theoremV4.7.13.py'
PHONE_TESTS=['test_migration_adds_recipes_without_mutating_original_records', 'test_last_record_of_each_domain_recovers_exactly', 'test_dependent_gaps_within_each_domain', 'test_cross_archive_chain_role_to_calculus', 'test_cross_archive_symbolic_complex_bridge', 'test_conflicting_recipe_never_replaces_missing_slot', 'test_absent_recipe_and_key_retains_pending', 'test_recovery_does_not_increment_archive_passage_counts', 'test_source_bytes_preserved_then_recovered_copy_continues', 'test_adaptive_chooses_verified_recovery_for_typed_loss']
def bundle_folder():
    candidates=[]
    if '__file__' in globals():candidates.append(Path(__file__).resolve().parent)
    candidates.append(Path.cwd())
    for downloads in [Path('/storage/emulated/0/Download'),Path('/storage/emulated/0/Downloads')]:
        if downloads.is_dir():
            candidates.extend(sorted(downloads.glob('zero_theorem_task6*'),key=lambda p:p.stat().st_mtime,reverse=True))
            candidates.extend(sorted(downloads.glob('Zero_Theorem_Task5*'),key=lambda p:p.stat().st_mtime,reverse=True))
    for folder in candidates:
        if (folder/ENGINE).is_file() and (folder/'task4_fixture/baseline.json').is_file():return folder
    raise FileNotFoundError('Open run_task6_tests.py inside the extracted zero_theorem_task6_tests folder. Keep the engine and fixture folders beside it.')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--full',action='store_true');args=parser.parse_args()
    folder=bundle_folder();sys.path.insert(0,str(folder))
    spec=importlib.util.spec_from_file_location('task6_checks',folder/'test_zero_theorem_v4713_recovery.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    if args.full:
        suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(name) for name in [
          'test_zero_theorem_v4713_recovery','test_zero_theorem_v4713_domains','test_zero_theorem_v4713_adaptive',
          'test_zero_theorem_v4713_regression','test_recipe_consistency_v4713'])
    else:suite=unittest.TestSuite(module.TypedRecoveryTests(name) for name in PHONE_TESTS)
    print('TASK 6 | engine:',ENGINE,'| bundle:',folder,flush=True)
    log=io.StringIO();started=time.perf_counter()
    class LiveResult(unittest.TextTestResult):
        def addSuccess(self,test):
            super().addSuccess(test);print('  PASS |',test._testMethodName,flush=True)
        def addFailure(self,test,err):
            super().addFailure(test,err);print('  FAIL |',test._testMethodName,flush=True)
        def addError(self,test,err):
            super().addError(test,err);print('  ERROR |',test._testMethodName,flush=True)
    result=unittest.TextTestRunner(stream=log,verbosity=2,resultclass=LiveResult).run(suite)
    report={'engine':ENGINE,'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
      'passed':result.wasSuccessful(),'seconds':round(time.perf_counter()-started,4),'scope':'disposable fixtures; no user memory opened',
      'details':log.getvalue()}
    output=folder/'task6_phone_results.json';output.write_text(json.dumps(report,indent=2)+'\n')
    if not result.wasSuccessful():print(log.getvalue())
    print('\nTASK 6:',result.testsRun-len(result.failures)-len(result.errors),'/',result.testsRun,'checks passed.')
    print('Test inputs were disposable copies. No user memory opened.')
    print('Full results:',output)
    return 0 if result.wasSuccessful() else 1

if __name__=='__main__':raise SystemExit(main())
